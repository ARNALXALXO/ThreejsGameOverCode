import * as THREE from '/jsm/three.module.js';
  import { OrbitControls } from '/jsm/OrbitControls.js';
  const renderer = new THREE.WebGLRenderer();
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  const scene = new THREE.Scene();

  const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 1, 10000);
  
var light = new THREE.AmbientLight(0xffffff, 0.5);
scene.add(light);

// -z side 
var light1 = new THREE.PointLight(0xffffff, 0.5);
light1.position.set(0,1500,0);
scene.add(light1);


renderer.setClearColor('darkorange'); 







  
 //=========== object class  =========
export default class game{
  place(){
  // place color = saddlebrown
var geometry = new THREE.ConeGeometry(1500,5,15);

var material = new THREE.MeshLambertMaterial(
{
  color: 'saddlebrown'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(0, -400, 0);
scene.add(mesh);      
//===========maintains ==========    
var geometry = new THREE.CylinderGeometry(10, 200, 350,10);

var material = new THREE.MeshLambertMaterial(
{
  color: 'saddlebrown'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-200, 165, -400);
scene.add(mesh);
//=======maintains 2=======
var geometry = new THREE.CylinderGeometry(10, 200, 250, 10);

var material = new THREE.MeshLambertMaterial(
{
  color: 'saddlebrown'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(0, 120, -400);
scene.add(mesh);
//=====maintain 3========
var geometry = new THREE.CylinderGeometry(10, 200, 250, 10);

var material = new THREE.MeshLambertMaterial(
{
  color: 'saddlebrown'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(200, 120, -400);
scene.add(mesh);
//=======pathar 1=========
var geometry = new THREE.DodecahedronGeometry(100, 0);

var material = new THREE.MeshLambertMaterial(
{
  color: 'gray'
});
var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(0, 0, -300);
scene.add(mesh);
//=======pathar 2=========
var geometry = new THREE.DodecahedronGeometry(100, 0);

var material = new THREE.MeshLambertMaterial(
{
  color: 'gray'
});
var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(50, 0, -300);
scene.add(mesh);
//=======pathar 3=========
var geometry = new THREE.DodecahedronGeometry(100, 0);

var material = new THREE.MeshLambertMaterial(
{
  color:  'gray'
});
var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(200, 0, -300);
scene.add(mesh);
//====pathar left side =====
//=======pathar 1=========
var geometry = new THREE.DodecahedronGeometry(100, 0);

var material = new THREE.MeshLambertMaterial(
{
  color: 'gray'
});
var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-50, 0, -300);
scene.add(mesh);
//=======pathar 2=========
var geometry = new THREE.DodecahedronGeometry(100, 0);

var material = new THREE.MeshLambertMaterial(
{
  color:  'gray'
});
var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-200, 0, -300);
scene.add(mesh);
//=======pathar 3=========
var geometry = new THREE.DodecahedronGeometry(100, 0);

var material = new THREE.MeshLambertMaterial(
{
  color: 'gray'
});
var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-300, 0, -300);
scene.add(mesh);
//==pathar - z side ========
//=======pathar 1=========
var geometry = new THREE.DodecahedronGeometry(300, 0);

var material = new THREE.MeshLambertMaterial(
{
  color: 'gray'
});
var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-50, -150, -400);
scene.add(mesh);
//=======pathar 2=========
var geometry = new THREE.DodecahedronGeometry(300, 0);

var material = new THREE.MeshLambertMaterial(
{
  color:  'gray'
});
var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-300, -150, -400);
scene.add(mesh);
//=======pathar 3=========
var geometry = new THREE.DodecahedronGeometry(300, 0);

var material = new THREE.MeshLambertMaterial(
{
  color: 'gray'
});
var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(300, -150, -400);
scene.add(mesh);



  }
//======Trees coding start =======  
 treeLeft(){
//============Tree 1==============
var geometry = new THREE.CylinderGeometry(10, 10,100 ,10);

var material = new THREE.MeshLambertMaterial(
{
  color: 'brown'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(0, 100, -250);
scene.add(mesh);
//=====
var geometry = new THREE.CylinderGeometry(2, 30, 150);

var material = new THREE.MeshLambertMaterial(
{
  color: 'green'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(0, 210, -250);
scene.add(mesh);

//============Tree 2==============
var geometry = new THREE.CylinderGeometry(10, 10, 100, 10);

var material = new THREE.MeshLambertMaterial(
{
  color: 'brown'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(70, 100, -295);
scene.add(mesh);
//=====
var geometry = new THREE.CylinderGeometry(2, 30, 100);

var material = new THREE.MeshLambertMaterial(
{
  color: 'green'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(70, 200, -295);
scene.add(mesh);      
//============Tree 3==============
var geometry = new THREE.CylinderGeometry(10, 10, 100, 10);

var material = new THREE.MeshLambertMaterial(
{
  color: 'brown'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(300, 100, -250);
scene.add(mesh);
//=====
var geometry = new THREE.CylinderGeometry(2, 30, 150);

var material = new THREE.MeshLambertMaterial(
{
  color: 'green'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(300, 210, -250);
scene.add(mesh);      
//============Tree 4==============
var geometry = new THREE.CylinderGeometry(10, 10, 100, 10);

var material = new THREE.MeshLambertMaterial(
{
  color: 'brown'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(400, 170, -380);
scene.add(mesh);
//=====
var geometry = new THREE.CylinderGeometry(2, 30, 150);

var material = new THREE.MeshLambertMaterial(
{
  color: 'green'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(400, 280, -380);
scene.add(mesh);      
//============Tree 5==============
var geometry = new THREE.CylinderGeometry(10, 10, 100, 10);

var material = new THREE.MeshLambertMaterial(
{
  color: 'brown'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-400, 170, -380);
scene.add(mesh);
//=====
var geometry = new THREE.CylinderGeometry(2, 30, 150);

var material = new THREE.MeshLambertMaterial(
{
  color: 'green'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-400, 280, -380);
scene.add(mesh);      
//============Tree 6==============
var geometry = new THREE.CylinderGeometry(10, 10, 100, 10);

var material = new THREE.MeshLambertMaterial(
{
  color: 'brown'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-400, 80, -250);
scene.add(mesh);
//=====
var geometry = new THREE.CylinderGeometry(2, 30, 150);

var material = new THREE.MeshLambertMaterial(
{
  color: 'green'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-400, 180, -250);
scene.add(mesh);      
//============Tree 7==============
var geometry = new THREE.CylinderGeometry(10, 10, 100, 10);

var material = new THREE.MeshLambertMaterial(
{
  color: 'brown'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-300, 80, -250);
scene.add(mesh);
//=====
var geometry = new THREE.CylinderGeometry(2, 30, 180);

var material = new THREE.MeshLambertMaterial(
{
  color: 'green'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-300, 220, -250);
scene.add(mesh);
//============Tree 8==============
var geometry = new THREE.CylinderGeometry(10, 10, 100, 10);

var material = new THREE.MeshLambertMaterial(
{
  color: 'brown'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-200, 80, -220);
scene.add(mesh);
//=====
var geometry = new THREE.CylinderGeometry(2, 30, 150);

var material = new THREE.MeshLambertMaterial(
{
  color: 'green'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-200, 180, -220);
scene.add(mesh);
//============Tree 9==============
var geometry = new THREE.CylinderGeometry(10, 10, 100, 10);

var material = new THREE.MeshLambertMaterial(
{
  color: 'brown'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-200, 50, -600);
scene.add(mesh);
//=====
var geometry = new THREE.CylinderGeometry(2, 30, 150);

var material = new THREE.MeshLambertMaterial(
{
  color: 'green'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-200, 170, -600);
scene.add(mesh);

//============Tree 10==============
var geometry = new THREE.CylinderGeometry(10, 10, 100, 10);

var material = new THREE.MeshLambertMaterial(
{
  color: 'brown'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-380, 50, -600);
scene.add(mesh);
//=====
var geometry = new THREE.CylinderGeometry(2, 30, 150);

var material = new THREE.MeshLambertMaterial(
{
  color: 'green'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(-380, 130, -600);
scene.add(mesh);
//============Tree 11==============
var geometry = new THREE.CylinderGeometry(10, 10, 100, 10);

var material = new THREE.MeshLambertMaterial(
{
  color: 'brown'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(300, 50, -600);
scene.add(mesh);
//=====
var geometry = new THREE.CylinderGeometry(2, 30, 150);

var material = new THREE.MeshLambertMaterial(
{
  color: 'green'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(300, 170, -600);
scene.add(mesh);

//============Tree 12==============
var geometry = new THREE.CylinderGeometry(10, 10, 100, 10);

var material = new THREE.MeshLambertMaterial(
{
  color: 'brown'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(0, 50, -580);
scene.add(mesh);
//=====
var geometry = new THREE.CylinderGeometry(2, 30, 150);

var material = new THREE.MeshLambertMaterial(
{
  color: 'green'
});

var mesh = new THREE.Mesh(geometry, material);
mesh.position.set(0, 170, -580);
scene.add(mesh);

  }
//======train, patri functions======
train(){
var geometry = new THREE.IcosahedronGeometry(100, 0);

var material = new THREE.MeshLambertMaterial(
{
  color: 'cyan'
});
var m1 = new THREE.Mesh(geometry, material);
m1.position.set(0, -330, 300);
scene.add(m1);
//==============m2=====
var geometry = new THREE.IcosahedronGeometry(100, 0);

var material = new THREE.MeshLambertMaterial(
{
  color: 0xF3FFE2
});
var m2 = new THREE.Mesh(geometry, material);
m2.position.set(500, -330, 300);
scene.add(m2);
//==============m3=====
var geometry = new THREE.IcosahedronGeometry(100, 0);

var material = new THREE.MeshLambertMaterial(
{
  color: 0xF3FFE2
});
var m3 = new THREE.Mesh(geometry, material);
m3.position.set(500, -330, 900);
scene.add(m3);

//==============m4 =====
var geometry = new THREE.IcosahedronGeometry(100, 0);

var material = new THREE.MeshLambertMaterial(
{
  color: 0xF3FFE2
});
var m4 = new THREE.Mesh(geometry, material);
m4.position.set(1100, -330, 900);
scene.add(m4);
//==============m5 =====
var geometry = new THREE.IcosahedronGeometry(100, 0);

var material = new THREE.MeshLambertMaterial(
{
  color: 0xF3FFE2
});
var m5 = new THREE.Mesh(geometry, material);
m5.position.set(1100, -330, 100);
scene.add(m5);
//==============m6 =====
var geometry = new THREE.IcosahedronGeometry(100, 0);

var material = new THREE.MeshLambertMaterial(
{
  color: 0xF3FFE2
});
var m4 = new THREE.Mesh(geometry, material);
m4.position.set(1100, -330, -700);
scene.add(m4);
//==============m7 =====
var geometry = new THREE.IcosahedronGeometry(100, 0);

var material = new THREE.MeshLambertMaterial(
{
  color: 0xF3FFE2
});
var m7 = new THREE.Mesh(geometry, material);
m7.position.set(700, -330, -700);
scene.add(m7);
//==============m8 =====
var geometry = new THREE.IcosahedronGeometry(100, 0);

var material = new THREE.MeshLambertMaterial(
{
  color: 0xF3FFE2
});
var m8 = new THREE.Mesh(geometry, material);
m8.position.set(700, -330, -1100);
scene.add(m8);

//==============m9 =====
var geometry = new THREE.IcosahedronGeometry(100, 0);

var material = new THREE.MeshLambertMaterial(
{
  color: 0xF3FFE2
});
var m9 = new THREE.Mesh(geometry, material);
m9.position.set(-700, -330, -1100);
scene.add(m9);








//==============train=====
var ge = new THREE.IcosahedronGeometry(-100, 0);

var material = new THREE.MeshLambertMaterial(
{
  color:'white'
});
var mesh = new THREE.Mesh(ge, material);
mesh.position.set(-700, -330, 300);
scene.add(mesh);  
 //========== 
 var ge = new THREE.IcosahedronGeometry(-100, 0);
 
 var material = new THREE.MeshLambertMaterial(
 {
   color: 'white'
 });
 var g = new THREE.Mesh(ge, material);
 g.position.set(0, -330, 800);
 scene.add(g);
//==========move buttons ========



//=============bt End ===============
function timeer() {
  var con = document.getElementById('con').value;
  document.getElementById("btn1").innerHTML=con;
  

/*===========if1=========*/
if (con == 0) {
  var move1 = g.position.x = -200;
  var move2 = g.position.z -= 0.5;
}
/*===========if1=========*/
if (con > 50) {
  var move1 = g.position.x = +200;
  var move2 = g.position.z -= 0.5;
}
/*===========if1=========*/
if (con == 100) {
  var move1 = g.position.x = 0;
  var a = g.position.z -= 0.5;
  var b = m1.position.z +=0;
//====else if1=====
//====else if2=====

  if (a < b) {
    console.log('move');
  }else if(a >b){
    console.log('start game move');
  }else{
    console.log('game over! ');
    alert('game over ');
  }
  
  
}
}
//=======setInterval function======
setInterval(timeer, 10);
//=========button function=====

//===========second function 
  
  
  
  
  
  








} 
}
//======================
  const controls = new OrbitControls(camera, renderer.domElement);

//================================
  camera.position.set(0, 200, 1200);
  controls.update();

function animate() {
  requestAnimationFrame(animate);
  controls.update();

  renderer.render(scene, camera);
}
animate();

