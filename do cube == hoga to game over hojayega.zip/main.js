import game from'/gameCode.js';

const apt =new game();

apt.place();
apt.treeLeft();
apt.train();




/*    ===animation code====


var time = setTimeout(function() {
  g.position.x += 0.9;
}, 1000);
var time = setTimeout(function() {
  g.position.x -= 0.9;
}, 14000);
var time = setTimeout(function() {
  g.position.z += 0.9;
}, 15000);
var time = setTimeout(function() {
  g.position.z -= 0.9;
}, 22000);
var time = setTimeout(function() {
  g.position.x += 0.9;
}, 23000);
var time = setTimeout(function() {
  g.position.x -= 0.9;
}, 30000);
var time = setTimeout(function() {
  g.position.z -= 0.9;
}, 31000);
var time = setTimeout(function() {
  g.position.z += 0.9;
}, 50000);
var time = setTimeout(function() {
  g.position.x -= 0.9;
}, 51000);
var time = setTimeout(function() {
  g.position.x += 0.9;
}, 56000);
var time = setTimeout(function() {
  g.position.z -= 0.9;
}, 57000);
var time = setTimeout(function() {
  g.position.z += 0.9;
}, 61000);
var time = setTimeout(function() {
  g.position.x -= 0.9;
}, 61000);
var time = setTimeout(function() {
  g.position.x += 0.9;
}, 78000);
var time = setTimeout(function() {
  g.position.z += 0.9;
}, 78000);


*/